\
    // Injects the shared header into every page and wires up behaviour
    (function () {
      function ensureMount() {
        var root = document.getElementById('site-header');
        if (root) return root;
        root = document.createElement('div');
        root.id = 'site-header';
        document.body.insertBefore(root, document.body.firstChild);
        return root;
      }

      if (location.protocol === 'file:') {
        console.warn('[NC header] Use a local server (fetch needs http/https).');
        return;
      }

      window.addEventListener('DOMContentLoaded', function () {
        var mount = ensureMount();
        fetch('partials/header.html', { cache: 'no-cache' })
          .then(function (r) { return r.text(); })
          .then(function (html) {
            mount.outerHTML = html;
            initNCHeader();
          })
          .catch(function (e) { console.error('[NC header] load failed', e); });
      });

      function initNCHeader () {
        var burger = document.querySelector('.hamburger');
        var menu = document.querySelector('.mobile-menu');
        var overlay = document.querySelector('.overlay');
        var closeBtn = document.querySelector('.close-btn');

        function close() {
          if (menu) menu.classList.remove('open');
          if (overlay) overlay.classList.remove('show');
        }

        if (burger && menu && overlay) {
          burger.addEventListener('click', function () {
            menu.classList.toggle('open');
            overlay.classList.toggle('show');
          });
          overlay.addEventListener('click', close);
          if (closeBtn) closeBtn.addEventListener('click', close);
          document.querySelectorAll('.mobile-menu a').forEach(function (a) {
            a.addEventListener('click', close);
          });
        }

        // Mobile accordion: one open at a time
        document.querySelectorAll('.menu-toggle').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var group = btn.parentElement;
            var isOpen = group.classList.contains('open');
            document.querySelectorAll('.menu-group').forEach(function (g) { g.classList.remove('open'); });
            if (!isOpen) group.classList.add('open');
            btn.setAttribute('aria-expanded', String(!isOpen));
          });
        });
      }
    })();
